
var port = 2333;
//var serverAddress = 'flip1.engr.oregonstate.edu:' + port;
var serverAddress = "";
